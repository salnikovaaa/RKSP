package pksp.exception;

public class ImageUploadException extends RuntimeException{
}
